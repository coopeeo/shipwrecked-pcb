# badge/
This folder provides the public-facing API for apps to use.