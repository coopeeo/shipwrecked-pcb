# Badge App API
For documentation, see [the wiki](https://github.com/mpkendall/shipwrecked-pcb/wiki/App-API-reference)